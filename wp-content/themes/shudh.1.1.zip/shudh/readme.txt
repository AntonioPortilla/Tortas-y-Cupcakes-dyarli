/*-----------------------------------------------------------------------------------*/
/* Free Minimal WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   Shudh
Theme URI       :   http://www.sktthemes.net/shop/free-minimal-wordpress-theme
Version         :   1.1
Tested up to    :   WP 4.5.3
Author          :   SKT Themes
Author URI      :   http://www.sktthemes.net/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@sktthemes.com

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.
- jquery.nivo.slider.js is licensed under MIT.


2 - Roboto Condensed - https://www.google.com/fonts/specimen/Roboto+Condensed
	License: Distributed under the terms of the Apache License, version 2.0 	http://www.apache.org/licenses/

3 - 	Images used from Pixabay.
	Pixabay provides images under CC0 license 		(https://creativecommons.org/about/cc0)

	Slides:
	https://pixabay.com/en/coffee-work-desk-mug-keyboard-1250405/
	https://pixabay.com/en/earphones-headphones-white-modern-791309/
	https://pixabay.com/en/creative-work-mockup-business-869200/
	

	Other Images:
	https://pixabay.com/en/light-bulb-light-led-lighting-1358917/
	https://pixabay.com/en/puzzle-cooperation-together-1020414/
	https://pixabay.com/en/woman-young-headset-service-851446/
	

For any help you can mail us at support[at]sktthemes.com