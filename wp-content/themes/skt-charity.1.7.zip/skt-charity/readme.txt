/*-----------------------------------------------------------------------------------*/
/* SKT Charity Responsive WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   SKT Charity
Theme URI       :   https://www.sktthemes.net/shop/skt-charity/
Version         :   1.7
Tested up to    :   WP 4.6.1
Author          :   SKT Themes
Author URI      :   https://www.sktthemes.net/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@sktthemes.com

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.
- jquery.nivo.slider.js is licensed under MIT.


2 - Roboto - https://www.google.com/fonts/specimen/Roboto
	License: Distributed under the terms of the Apache License, version 2.0 	http://www.apache.org/licenses/

3 - 	Images used from Pixabay.
	Pixabay provides images under CC0 license 			(https://creativecommons.org/about/cc0)

	Slides:
	https://pixabay.com/en/tanga-tanzania-boy-child-close-up-102577/
	https://pixabay.com/en/child-uganda-eyes-girl-close-up-251920/	
	https://pixabay.com/en/children-poor-mud-village-kids-60654/	

	Other Images:
	https://pixabay.com/en/mother-daughter-together-family-827754/
	

For any help you can mail us at support[at]sktthemes.com