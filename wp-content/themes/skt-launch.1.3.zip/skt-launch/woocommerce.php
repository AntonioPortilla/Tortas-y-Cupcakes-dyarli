<?php
/**
 * @package SKT Launch
 */
get_header();
?>
<div class="container inrpagecontent">
    		<div class="site-aligner">
			<?php woocommerce_content(); ?>
		   </div><!-- site-aligner -->
    </div><!-- content -->
     
<?php get_footer(); ?>